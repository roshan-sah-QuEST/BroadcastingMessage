//
//  ViewController.swift
//  POC
//
//  Created by Roshan Sah on 10/06/19.
//  Copyright © 2019 Roshan Sah. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    
    @IBOutlet weak var progressView: NSProgressIndicator!
    //
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
         //let _ = DownloadManager.shared.activate()

    }
    
    
    override func viewWillAppear() {
        super.viewWillAppear()
        DownloadManager.shared.onProgress = { (progress) in
            OperationQueue.main.addOperation {
               // print(progress)
                //self.progressView.progress = progress
            }
        }
        
    }
    
    override func viewWillDisappear() {
        super.viewWillDisappear()
        DownloadManager.shared.onProgress = nil
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    @IBAction func printMe(_ sender: Any) {
        print("I have action to print")
        let url = URL(string: "https://www.adobe.com/content/dam/acom/en/devnet/acrobat/pdfs/pdf_open_parameters.pdf")!
        let task = DownloadManager.shared.activate().downloadTask(with: url)
        task.resume()
        
    }


}

