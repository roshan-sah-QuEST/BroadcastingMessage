//
//  AppDelegate.swift
//  POC
//
//  Created by Roshan Sah on 10/06/19.
//  Copyright © 2019 Roshan Sah. All rights reserved.
//

import Cocoa
import Quartz

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    
    @IBAction func openPDF(_ sender: Any) {
        let printInfo = NSPrintInfo.shared
        let manager = FileManager.default
        do{
            
            let directoryURL = try manager.url(for: .documentDirectory, in:.userDomainMask, appropriateFor:nil, create:true)
            
            let docURL = NSURL(string:"CFNetworkDownload_C8iW6o.pdf", relativeTo:directoryURL)
            
            let pdfDoc =  PDFDocument.init(url: docURL! as URL)
            
            let page = CGRect(x: 0, y: 0, width: 595.2, height: 1841.8) // A4, 72 dpi
            
            let pdfView : PDFView = PDFView.init(frame: page)
            
            pdfView.document = pdfDoc
            
            let operation: NSPrintOperation = NSPrintOperation(view: pdfView, printInfo: printInfo)
            operation.printPanel.options.insert(NSPrintPanel.Options.showsPaperSize)
            operation.printPanel.options.insert(NSPrintPanel.Options.showsOrientation)
            
            operation.run()
        }catch{
            
        }
    }
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

